# DCAT: A Dynamic Cross-Attention Transformer for Conditional Multimodal Email Spam Detection

**Author:** Preetham S
**Email:** spreetham6442@gmail.com

## Main LaTeX file
`main.tex`

## Bibliography
`references.bib`

## Figures
All figures (flowchart, architecture, plots, confusion matrices) are generated natively inline using TikZ and pgfplots vector code within `main.tex`. There are no external figure assets included in this package.

## Compilation
To compile the final paper, run the following sequence of commands in the directory containing `main.tex`:
```bash
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

## Final PDF
The source in this package corresponds to `DCAT_Final_Practice_Paper.pdf`.
